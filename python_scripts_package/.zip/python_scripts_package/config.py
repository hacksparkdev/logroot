WORKSTATIONS = [
    {'name': 'WORKSTATION1', 'user': 'Karen Picklebee', 'password': 'Password1!'},
    {'name': 'WORKSTATION1', 'user': 'Roger Adams', 'password': 'Password1!'},
]

LOGSTASH_HOST = 'localhost'
LOGSTASH_PORT = 5044



